# How to run PyGoatBot in Google Colab

Follow these steps to run the PyGoatBot code in Google Colab:
1. Open a new Google Colab notebook.
2. Install the ChatterBot library by running the following command: `!pip install chatterbot`
3. Copy and paste the code into a new cell.
4. Run the code cell.

## Usage
1. The PyGoatBot will prompt you to select a question from a list of available questions. 
2. Type the number of the question you want to ask, and the chatbot will respond.
3. To exit the chatbot, type 'q' or 'exit' when prompted.
